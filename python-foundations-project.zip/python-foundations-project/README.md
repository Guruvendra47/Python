# Introduction to Python: Building a Foundation for Data-Driven Careers

Welcome! This repo converts the **"Introduction to Python"** slide deck into a hands-on GitHub project so you can learn by doing.

---

## 🚀 Why Python?

- **Versatility:** Used across industries for data analysis, engineering, AI, automation, and more.  
- **Ease of Learning:** Simple syntax makes it beginner-friendly.  
- **Community & Support:** Vast libraries and an active community mean you’ll always find help.

---

## 🏢 Python in the Real World

- **Data Analysis:** Used by companies like Google, Netflix, and Spotify for insights.  
- **Data Engineering:** ETL (Extract, Transform, Load) at scale (e.g., Airbnb).  
- **Automation:** Script repetitive tasks and workflows across teams.

---

## 🆚 Python vs. Other Data Tools

- **Python vs. Excel:** Python handles larger datasets and automates repetitive tasks with scripts.  
- **Python vs. SQL:** SQL excels at querying databases; Python shines at data manipulation, analysis, and orchestration around SQL.

---

## 🔑 Python Features for Data

- **Core Data Structures:** Lists, dictionaries, sets, tuples.  
- **Popular Libraries:** `pandas`, `numpy`, `matplotlib`.  
- **Interoperability:** Works with SQL databases, big data tools, and cloud services (AWS, GCP, Azure).

---

## 🧠 Python Syntax Primer

- Variables and data types  
- Basic operations (arithmetic, string manipulation)  
- Control flow (if/else, loops)  
- Functions and modules

> See: [`scripts/example_basics.py`](scripts/example_basics.py)

---

## 🗂️ Working with Data in Python

- **Pandas for DataFrames:** Load, join, filter, aggregate.  
- **NumPy for Numerics:** Fast array operations for large data.  
- **Matplotlib for Viz:** Build charts, plots, and graphs.

> See:  
> • [`scripts/example_pandas.py`](scripts/example_pandas.py)  
> • [`scripts/example_matplotlib.py`](scripts/example_matplotlib.py)

---

## 🧱 Python’s Role in Data Engineering

- **Data Collection:** APIs, files, databases, web scraping.  
- **Data Processing:** ETL pipelines, cleaning, transformation.  
- **Data Storage:** SQL/NoSQL, files, data lakes.  
- **Automation:** Scheduled jobs and workflow orchestration.

---

## 🔄 Typical Data Workflow

1. **Data Collection** (APIs, databases, files)  
2. **Data Cleaning** (missing values, types)  
3. **Data Transformation** (aggregations, joins)  
4. **Data Storage** (databases, files, lakes)  
5. **Data Analysis & Visualization** (insights, charts)

---

## ✅ Best Practices

- Write clean, readable, modular code.  
- Comment and document thoughtfully.  
- Use version control (git).  
- Add unit tests where appropriate.

---

## 🖥️ Installation

- Download Python from the official site: https://www.python.org/downloads/  
- (Optional) Create a virtual environment:
  ```bash
  python -m venv .venv
  source .venv/bin/activate  # Windows: .venv\Scripts\activate
  ```
- Install dependencies:
  ```bash
  pip install -r requirements.txt
  ```

---

## ▶️ Run the Examples

```
python scripts/example_basics.py
python scripts/example_pandas.py
python scripts/example_matplotlib.py
```

---

## 📜 License

This project is released under the MIT License. See [LICENSE](LICENSE).
